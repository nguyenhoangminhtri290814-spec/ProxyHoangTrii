package com.hoangtrii.proxy;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.net.*;
import java.io.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,18,22), card = Color.rgb(32,35,41), orange = Color.rgb(255,157,24);
    private EditText hostInput, portInput, userInput, passInput;
    private TextView status;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("proxy_config", MODE_PRIVATE);
        buildHome();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void pad(View v, int n) { v.setPadding(n,n,n,n); }
    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w,h);
    }
    private void buildHome() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout page = column(); pad(page,20); scroll.addView(page);
        LinearLayout brand = new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView bear = new ImageView(this); bear.setImageResource(com.hoangtrii.proxy.R.drawable.bear_icon);
        brand.addView(bear, lp(76,76));
        LinearLayout names = column(); names.setPadding(14,0,0,0);
        names.addView(text("Proxy HoangTrii",25,Color.WHITE,true));
        names.addView(text("PROXY  •  VPN  •  UDP  •  SOCKS5",11,0xffaeb4bf,false));
        brand.addView(names); page.addView(brand);

        TextView banner=text("PROXY DISCONNECTED\nSẵn sàng kiểm tra máy chủ",20,Color.WHITE,true);
        pad(banner,22); banner.setGravity(Gravity.CENTER); banner.setBackground(shape(card,24));
        LinearLayout.LayoutParams bp=lp(-1,-2); bp.setMargins(0,24,0,14); page.addView(banner,bp);

        status=text("Chưa kiểm tra máy chủ",14,0xffc4c9d1,false);
        page.addView(status);
        Button test=new Button(this); test.setText("KIỂM TRA SOCKS5");
        test.setTextColor(Color.BLACK); test.setBackgroundTintList(android.content.res.ColorStateList.valueOf(orange));
        LinearLayout.LayoutParams tp=lp(-1,-2); tp.setMargins(0,14,0,20); page.addView(test,tp);
        test.setOnClickListener(v -> testSocks5());

        page.addView(section("CẤU HÌNH MÁY CHỦ"));
        hostInput=field("Địa chỉ máy chủ (IP hoặc domain)",prefs.getString("host",""));
        portInput=field("Cổng SOCKS5",prefs.getString("port","1080"));
        userInput=field("Tên đăng nhập (nếu có)",prefs.getString("user",""));
        passInput=field("Mật khẩu (nếu có)",prefs.getString("pass",""));
        page.addView(hostInput); page.addView(portInput); page.addView(userInput); page.addView(passInput);
        Button save=new Button(this); save.setText("LƯU CẤU HÌNH");
        page.addView(save); save.setOnClickListener(v -> {
            prefs.edit().putString("host",hostInput.getText().toString().trim())
                .putString("port",portInput.getText().toString().trim())
                .putString("user",userInput.getText().toString())
                .putString("pass",passInput.getText().toString()).apply();
            status.setText("Đã lưu cấu hình SOCKS5 trên thiết bị.");
        });

        page.addView(section("TIỆN ÍCH"));
        page.addView(tile("Máy chủ", "Thiết lập endpoint SOCKS5"));
        page.addView(tile("Chọn game", "Danh sách ứng dụng sẽ bổ sung ở bản VPN"));
        page.addView(tile("Thống kê UDP", "Theo dõi lưu lượng ở bản tích hợp tunnel"));
        page.addView(tile("Cài đặt", "Proxy HoangTrii v1.0.0"));
        page.addView(text("Không yêu cầu Key • Mở thẳng trang chính",12,0xff9da5b1,false));
        setContentView(scroll);
    }
    private TextView section(String s) {
        TextView t=text(s,13,orange,true); t.setPadding(0,20,0,8); return t;
    }
    private EditText field(String hint,String value) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint);
        e.setHintTextColor(0xff7f8792); e.setTextColor(Color.WHITE); e.setPadding(14,8,14,8);
        e.setBackground(shape(card,14));
        LinearLayout.LayoutParams p=lp(-1,52); p.setMargins(0,5,0,5); e.setLayoutParams(p); return e;
    }
    private View tile(String title,String sub) {
        LinearLayout box=column(); pad(box,16); box.setBackground(shape(card,16));
        TextView a=text(title,16,Color.WHITE,true), b=text(sub,12,0xffaeb4bf,false);
        box.addView(a); box.addView(b);
        LinearLayout.LayoutParams p=lp(-1,-2); p.setMargins(0,5,0,5); box.setLayoutParams(p); return box;
    }
    private void testSocks5() {
        final String host=hostInput.getText().toString().trim();
        final String portText=portInput.getText().toString().trim();
        final String user=userInput.getText().toString();
        final String pass=passInput.getText().toString();
        if(host.isEmpty() || portText.isEmpty()) { status.setText("Nhập địa chỉ máy chủ và cổng SOCKS5."); return; }
        status.setText("Đang kiểm tra endpoint...");
        new Thread(() -> {
            String result;
            try {
                int port=Integer.parseInt(portText);
                try (Socket s=new Socket()) {
                    s.connect(new InetSocketAddress(host,port),5000); s.setSoTimeout(5000);
                    InputStream in=s.getInputStream(); OutputStream out=s.getOutputStream();
                    boolean auth=!user.isEmpty();
                    out.write(auth ? new byte[]{5,2,0,2} : new byte[]{5,1,0}); out.flush();
                    int ver=in.read(), method=in.read();
                    if(ver!=5 || method==255) throw new IOException("Máy chủ từ chối phương thức SOCKS5");
                    if(method==2) {
                        byte[] ub=user.getBytes("UTF-8"), pb=pass.getBytes("UTF-8");
                        if(ub.length>255 || pb.length>255) throw new IOException("Thông tin xác thực quá dài");
                        out.write(1); out.write(ub.length); out.write(ub); out.write(pb.length); out.write(pb); out.flush();
                        if(in.read()!=1 || in.read()!=0) throw new IOException("Xác thực SOCKS5 thất bại");
                    } else if(method!=0) throw new IOException("Phương thức xác thực không được hỗ trợ");
                    result="Endpoint SOCKS5 phản hồi thành công: "+host+":"+port;
                }
            } catch(Exception e) { result="Kiểm tra thất bại: "+e.getMessage(); }
            final String r=result;
            runOnUiThread(() -> status.setText(r));
        }).start();
    }
}