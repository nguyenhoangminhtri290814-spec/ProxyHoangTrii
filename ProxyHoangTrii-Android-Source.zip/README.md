# Proxy HoangTrii — Android starter project

- App name: Proxy HoangTrii
- Bear launcher icon generated for this project
- Opens directly to the dashboard; no activation-key screen
- Android minSdk 23, targetSdk 35
- SOCKS5 endpoint settings and a real TCP/SOCKS5 greeting + optional username/password handshake test

## Build
Open this folder in Android Studio (JDK 17; Android SDK Platform 35), allow Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

## Current implementation boundary
This is an independent starter/MVP, not a full system-wide VPN yet. The SOCKS5 test verifies that the configured endpoint responds to the protocol handshake. It does not route Android device traffic through a TUN interface. UDP forwarding, per-app game selection, traffic statistics and floating controls require a tunnel engine and corresponding integration; those are not falsely marked as working in this starter.

The uploaded original APK contains native libraries (`libconnect.so`, `libhev-socks5-tunnel.so`) and references a remote dashboard at ff.gringoxp.site. This project does not copy those binaries or depend on that service.
